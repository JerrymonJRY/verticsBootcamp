# Responsive Nav Menu - HTML/CSS Only Mobile - Commented for Ease of Understanding

A Pen created on CodePen.io. Original URL: [https://codepen.io/phileflanagan/pen/jwbWKP](https://codepen.io/phileflanagan/pen/jwbWKP).

