# Responsive Navbar - CSS/ HTML ONLY

A Pen created on CodePen.io. Original URL: [https://codepen.io/rexdesigndk/pen/gJYExb](https://codepen.io/rexdesigndk/pen/gJYExb).

I build a responsive navbar for a project im working on. Therefore i decided to share it with you guys.

No javascript is used. It's only CSS3 and HTML.