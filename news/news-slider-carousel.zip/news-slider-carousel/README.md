# News Slider Carousel

A Pen created on CodePen.

Original URL: [https://codepen.io/gatoledo1/pen/zYYEazv](https://codepen.io/gatoledo1/pen/zYYEazv).

